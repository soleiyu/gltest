﻿namespace test
{
    partial class MainWindow
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer_main = new System.Windows.Forms.SplitContainer();
            this.tabControl_serialPortAndSettings = new System.Windows.Forms.TabControl();
            this.tabPage_serialPort = new System.Windows.Forms.TabPage();
            this.groupBox_settings = new System.Windows.Forms.GroupBox();
            this.button_sendRequest = new System.Windows.Forms.Button();
            this.textBox_vectorLog = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel_settings = new System.Windows.Forms.TableLayoutPanel();
            this.label_parserVector = new System.Windows.Forms.Label();
            this.textBox_serialPortDataBits = new System.Windows.Forms.TextBox();
            this.textBox_serialPortBaudRate = new System.Windows.Forms.TextBox();
            this.label_serialPortDataBits = new System.Windows.Forms.Label();
            this.label_serialPortBaudRate = new System.Windows.Forms.Label();
            this.label_beginVector = new System.Windows.Forms.Label();
            this.label_getVectorOperation = new System.Windows.Forms.Label();
            this.label_endVector = new System.Windows.Forms.Label();
            this.textBox_getVectorOperation = new System.Windows.Forms.TextBox();
            this.textBox_beginVector = new System.Windows.Forms.TextBox();
            this.textBox_endVector = new System.Windows.Forms.TextBox();
            this.textBox_parserVector = new System.Windows.Forms.TextBox();
            this.groupBox_port = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel_serialPortMode = new System.Windows.Forms.FlowLayoutPanel();
            this.radioButton_serialPortConnect = new System.Windows.Forms.RadioButton();
            this.radioButton_serialPortDisconnect = new System.Windows.Forms.RadioButton();
            this.comboBox_port = new System.Windows.Forms.ComboBox();
            this.tabPage_settings = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_main)).BeginInit();
            this.splitContainer_main.Panel1.SuspendLayout();
            this.splitContainer_main.SuspendLayout();
            this.tabControl_serialPortAndSettings.SuspendLayout();
            this.tabPage_serialPort.SuspendLayout();
            this.groupBox_settings.SuspendLayout();
            this.tableLayoutPanel_settings.SuspendLayout();
            this.groupBox_port.SuspendLayout();
            this.flowLayoutPanel_serialPortMode.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer_main
            // 
            this.splitContainer_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_main.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_main.Name = "splitContainer_main";
            // 
            // splitContainer_main.Panel1
            // 
            this.splitContainer_main.Panel1.Controls.Add(this.tabControl_serialPortAndSettings);
            this.splitContainer_main.Size = new System.Drawing.Size(800, 450);
            this.splitContainer_main.SplitterDistance = 266;
            this.splitContainer_main.TabIndex = 0;
            // 
            // tabControl_serialPortAndSettings
            // 
            this.tabControl_serialPortAndSettings.Controls.Add(this.tabPage_serialPort);
            this.tabControl_serialPortAndSettings.Controls.Add(this.tabPage_settings);
            this.tabControl_serialPortAndSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_serialPortAndSettings.Location = new System.Drawing.Point(0, 0);
            this.tabControl_serialPortAndSettings.Name = "tabControl_serialPortAndSettings";
            this.tabControl_serialPortAndSettings.SelectedIndex = 0;
            this.tabControl_serialPortAndSettings.Size = new System.Drawing.Size(266, 450);
            this.tabControl_serialPortAndSettings.TabIndex = 0;
            // 
            // tabPage_serialPort
            // 
            this.tabPage_serialPort.Controls.Add(this.groupBox_settings);
            this.tabPage_serialPort.Controls.Add(this.groupBox_port);
            this.tabPage_serialPort.Location = new System.Drawing.Point(4, 22);
            this.tabPage_serialPort.Name = "tabPage_serialPort";
            this.tabPage_serialPort.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_serialPort.Size = new System.Drawing.Size(258, 424);
            this.tabPage_serialPort.TabIndex = 0;
            this.tabPage_serialPort.Text = "SerialPort";
            this.tabPage_serialPort.UseVisualStyleBackColor = true;
            // 
            // groupBox_settings
            // 
            this.groupBox_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_settings.Controls.Add(this.button_sendRequest);
            this.groupBox_settings.Controls.Add(this.textBox_vectorLog);
            this.groupBox_settings.Controls.Add(this.tableLayoutPanel_settings);
            this.groupBox_settings.Location = new System.Drawing.Point(6, 51);
            this.groupBox_settings.Name = "groupBox_settings";
            this.groupBox_settings.Size = new System.Drawing.Size(246, 365);
            this.groupBox_settings.TabIndex = 1;
            this.groupBox_settings.TabStop = false;
            this.groupBox_settings.Text = "Settings";
            // 
            // button_sendRequest
            // 
            this.button_sendRequest.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_sendRequest.AutoSize = true;
            this.button_sendRequest.Location = new System.Drawing.Point(75, 333);
            this.button_sendRequest.Name = "button_sendRequest";
            this.button_sendRequest.Size = new System.Drawing.Size(82, 23);
            this.button_sendRequest.TabIndex = 2;
            this.button_sendRequest.Text = "SendRequest";
            this.button_sendRequest.UseVisualStyleBackColor = true;
            this.button_sendRequest.Click += new System.EventHandler(this.serialPort_sendData);
            // 
            // textBox_vectorLog
            // 
            this.textBox_vectorLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_vectorLog.Location = new System.Drawing.Point(7, 176);
            this.textBox_vectorLog.Multiline = true;
            this.textBox_vectorLog.Name = "textBox_vectorLog";
            this.textBox_vectorLog.Size = new System.Drawing.Size(233, 151);
            this.textBox_vectorLog.TabIndex = 1;
            // 
            // tableLayoutPanel_settings
            // 
            this.tableLayoutPanel_settings.AutoSize = true;
            this.tableLayoutPanel_settings.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_settings.ColumnCount = 2;
            this.tableLayoutPanel_settings.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel_settings.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel_settings.Controls.Add(this.label_parserVector, 0, 5);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_serialPortDataBits, 1, 0);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_serialPortBaudRate, 1, 1);
            this.tableLayoutPanel_settings.Controls.Add(this.label_serialPortDataBits, 0, 0);
            this.tableLayoutPanel_settings.Controls.Add(this.label_serialPortBaudRate, 0, 1);
            this.tableLayoutPanel_settings.Controls.Add(this.label_beginVector, 0, 3);
            this.tableLayoutPanel_settings.Controls.Add(this.label_getVectorOperation, 0, 2);
            this.tableLayoutPanel_settings.Controls.Add(this.label_endVector, 0, 4);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_getVectorOperation, 1, 2);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_beginVector, 1, 3);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_endVector, 1, 4);
            this.tableLayoutPanel_settings.Controls.Add(this.textBox_parserVector, 1, 5);
            this.tableLayoutPanel_settings.Location = new System.Drawing.Point(7, 19);
            this.tableLayoutPanel_settings.Name = "tableLayoutPanel_settings";
            this.tableLayoutPanel_settings.RowCount = 6;
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_settings.Size = new System.Drawing.Size(171, 150);
            this.tableLayoutPanel_settings.TabIndex = 0;
            // 
            // label_parserVector
            // 
            this.label_parserVector.AutoSize = true;
            this.label_parserVector.Location = new System.Drawing.Point(3, 125);
            this.label_parserVector.Name = "label_parserVector";
            this.label_parserVector.Size = new System.Drawing.Size(38, 12);
            this.label_parserVector.TabIndex = 7;
            this.label_parserVector.Text = "Parser";
            // 
            // textBox_serialPortDataBits
            // 
            this.textBox_serialPortDataBits.Location = new System.Drawing.Point(68, 3);
            this.textBox_serialPortDataBits.Name = "textBox_serialPortDataBits";
            this.textBox_serialPortDataBits.Size = new System.Drawing.Size(100, 19);
            this.textBox_serialPortDataBits.TabIndex = 0;
            // 
            // textBox_serialPortBaudRate
            // 
            this.textBox_serialPortBaudRate.Location = new System.Drawing.Point(68, 28);
            this.textBox_serialPortBaudRate.Name = "textBox_serialPortBaudRate";
            this.textBox_serialPortBaudRate.Size = new System.Drawing.Size(100, 19);
            this.textBox_serialPortBaudRate.TabIndex = 1;
            // 
            // label_serialPortDataBits
            // 
            this.label_serialPortDataBits.AutoSize = true;
            this.label_serialPortDataBits.Location = new System.Drawing.Point(3, 0);
            this.label_serialPortDataBits.Name = "label_serialPortDataBits";
            this.label_serialPortDataBits.Size = new System.Drawing.Size(54, 12);
            this.label_serialPortDataBits.TabIndex = 2;
            this.label_serialPortDataBits.Text = "Data Bits";
            // 
            // label_serialPortBaudRate
            // 
            this.label_serialPortBaudRate.AutoSize = true;
            this.label_serialPortBaudRate.Location = new System.Drawing.Point(3, 25);
            this.label_serialPortBaudRate.Name = "label_serialPortBaudRate";
            this.label_serialPortBaudRate.Size = new System.Drawing.Size(59, 12);
            this.label_serialPortBaudRate.TabIndex = 3;
            this.label_serialPortBaudRate.Text = "Baud Rate";
            // 
            // label_beginVector
            // 
            this.label_beginVector.AutoSize = true;
            this.label_beginVector.Location = new System.Drawing.Point(3, 75);
            this.label_beginVector.Name = "label_beginVector";
            this.label_beginVector.Size = new System.Drawing.Size(34, 12);
            this.label_beginVector.TabIndex = 5;
            this.label_beginVector.Text = "Begin";
            // 
            // label_getVectorOperation
            // 
            this.label_getVectorOperation.AutoSize = true;
            this.label_getVectorOperation.Location = new System.Drawing.Point(3, 50);
            this.label_getVectorOperation.Name = "label_getVectorOperation";
            this.label_getVectorOperation.Size = new System.Drawing.Size(54, 12);
            this.label_getVectorOperation.TabIndex = 4;
            this.label_getVectorOperation.Text = "Operation";
            // 
            // label_endVector
            // 
            this.label_endVector.AutoSize = true;
            this.label_endVector.Location = new System.Drawing.Point(3, 100);
            this.label_endVector.Name = "label_endVector";
            this.label_endVector.Size = new System.Drawing.Size(24, 12);
            this.label_endVector.TabIndex = 6;
            this.label_endVector.Text = "End";
            // 
            // textBox_getVectorOperation
            // 
            this.textBox_getVectorOperation.Location = new System.Drawing.Point(68, 53);
            this.textBox_getVectorOperation.Name = "textBox_getVectorOperation";
            this.textBox_getVectorOperation.Size = new System.Drawing.Size(100, 19);
            this.textBox_getVectorOperation.TabIndex = 8;
            // 
            // textBox_beginVector
            // 
            this.textBox_beginVector.Location = new System.Drawing.Point(68, 78);
            this.textBox_beginVector.Name = "textBox_beginVector";
            this.textBox_beginVector.Size = new System.Drawing.Size(100, 19);
            this.textBox_beginVector.TabIndex = 9;
            // 
            // textBox_endVector
            // 
            this.textBox_endVector.Location = new System.Drawing.Point(68, 103);
            this.textBox_endVector.Name = "textBox_endVector";
            this.textBox_endVector.Size = new System.Drawing.Size(100, 19);
            this.textBox_endVector.TabIndex = 10;
            // 
            // textBox_parserVector
            // 
            this.textBox_parserVector.Location = new System.Drawing.Point(68, 128);
            this.textBox_parserVector.Name = "textBox_parserVector";
            this.textBox_parserVector.Size = new System.Drawing.Size(100, 19);
            this.textBox_parserVector.TabIndex = 11;
            // 
            // groupBox_port
            // 
            this.groupBox_port.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_port.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox_port.Controls.Add(this.flowLayoutPanel_serialPortMode);
            this.groupBox_port.Controls.Add(this.comboBox_port);
            this.groupBox_port.Location = new System.Drawing.Point(6, 6);
            this.groupBox_port.Name = "groupBox_port";
            this.groupBox_port.Size = new System.Drawing.Size(246, 39);
            this.groupBox_port.TabIndex = 0;
            this.groupBox_port.TabStop = false;
            this.groupBox_port.Text = "Port";
            // 
            // flowLayoutPanel_serialPortMode
            // 
            this.flowLayoutPanel_serialPortMode.AutoSize = true;
            this.flowLayoutPanel_serialPortMode.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel_serialPortMode.Controls.Add(this.radioButton_serialPortConnect);
            this.flowLayoutPanel_serialPortMode.Controls.Add(this.radioButton_serialPortDisconnect);
            this.flowLayoutPanel_serialPortMode.Location = new System.Drawing.Point(84, 11);
            this.flowLayoutPanel_serialPortMode.Name = "flowLayoutPanel_serialPortMode";
            this.flowLayoutPanel_serialPortMode.Size = new System.Drawing.Size(157, 22);
            this.flowLayoutPanel_serialPortMode.TabIndex = 1;
            // 
            // radioButton_serialPortConnect
            // 
            this.radioButton_serialPortConnect.AutoSize = true;
            this.radioButton_serialPortConnect.Location = new System.Drawing.Point(3, 3);
            this.radioButton_serialPortConnect.Name = "radioButton_serialPortConnect";
            this.radioButton_serialPortConnect.Size = new System.Drawing.Size(65, 16);
            this.radioButton_serialPortConnect.TabIndex = 0;
            this.radioButton_serialPortConnect.Text = "Connect";
            this.radioButton_serialPortConnect.UseVisualStyleBackColor = true;
            this.radioButton_serialPortConnect.CheckedChanged += new System.EventHandler(this.radioButton_serialPortConnect_CheckedChanged);
            // 
            // radioButton_serialPortDisconnect
            // 
            this.radioButton_serialPortDisconnect.AutoSize = true;
            this.radioButton_serialPortDisconnect.Checked = true;
            this.radioButton_serialPortDisconnect.Location = new System.Drawing.Point(74, 3);
            this.radioButton_serialPortDisconnect.Name = "radioButton_serialPortDisconnect";
            this.radioButton_serialPortDisconnect.Size = new System.Drawing.Size(80, 16);
            this.radioButton_serialPortDisconnect.TabIndex = 1;
            this.radioButton_serialPortDisconnect.TabStop = true;
            this.radioButton_serialPortDisconnect.Text = "Disconnect";
            this.radioButton_serialPortDisconnect.UseVisualStyleBackColor = true;
            this.radioButton_serialPortDisconnect.CheckedChanged += new System.EventHandler(this.radioButton_serialPortDisconnect_CheckedChanged);
            // 
            // comboBox_port
            // 
            this.comboBox_port.FormattingEnabled = true;
            this.comboBox_port.Location = new System.Drawing.Point(6, 13);
            this.comboBox_port.Name = "comboBox_port";
            this.comboBox_port.Size = new System.Drawing.Size(72, 20);
            this.comboBox_port.TabIndex = 0;
            // 
            // tabPage_settings
            // 
            this.tabPage_settings.Location = new System.Drawing.Point(4, 22);
            this.tabPage_settings.Name = "tabPage_settings";
            this.tabPage_settings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_settings.Size = new System.Drawing.Size(258, 424);
            this.tabPage_settings.TabIndex = 1;
            this.tabPage_settings.Text = "tabPage2";
            this.tabPage_settings.UseVisualStyleBackColor = true;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer_main);
            this.Name = "MainWindow";
            this.Text = "SV2";
            this.splitContainer_main.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_main)).EndInit();
            this.splitContainer_main.ResumeLayout(false);
            this.tabControl_serialPortAndSettings.ResumeLayout(false);
            this.tabPage_serialPort.ResumeLayout(false);
            this.groupBox_settings.ResumeLayout(false);
            this.groupBox_settings.PerformLayout();
            this.tableLayoutPanel_settings.ResumeLayout(false);
            this.tableLayoutPanel_settings.PerformLayout();
            this.groupBox_port.ResumeLayout(false);
            this.groupBox_port.PerformLayout();
            this.flowLayoutPanel_serialPortMode.ResumeLayout(false);
            this.flowLayoutPanel_serialPortMode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer_main;
        private System.Windows.Forms.TabControl tabControl_serialPortAndSettings;
        private System.Windows.Forms.TabPage tabPage_serialPort;
        private System.Windows.Forms.TabPage tabPage_settings;
        private System.Windows.Forms.GroupBox groupBox_port;
        private System.Windows.Forms.ComboBox comboBox_port;
        private System.Windows.Forms.GroupBox groupBox_settings;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_serialPortMode;
        private System.Windows.Forms.RadioButton radioButton_serialPortConnect;
        private System.Windows.Forms.RadioButton radioButton_serialPortDisconnect;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_settings;
        private System.Windows.Forms.Label label_parserVector;
        private System.Windows.Forms.TextBox textBox_serialPortDataBits;
        private System.Windows.Forms.TextBox textBox_serialPortBaudRate;
        private System.Windows.Forms.Label label_serialPortDataBits;
        private System.Windows.Forms.Label label_serialPortBaudRate;
        private System.Windows.Forms.Label label_beginVector;
        private System.Windows.Forms.Label label_getVectorOperation;
        private System.Windows.Forms.Label label_endVector;
        private System.Windows.Forms.TextBox textBox_getVectorOperation;
        private System.Windows.Forms.TextBox textBox_beginVector;
        private System.Windows.Forms.TextBox textBox_endVector;
        private System.Windows.Forms.TextBox textBox_parserVector;
        private System.Windows.Forms.TextBox textBox_vectorLog;
        private System.Windows.Forms.Button button_sendRequest;
    }
}

