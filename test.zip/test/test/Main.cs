﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;

namespace test
{
    public partial class MainWindow : Form
    {
        GLControl glControl = null;

        private Color4 backGround = new Color4(0.8f, 0.87f, 0.9f, 1.0f);

        private Vector3 eye = new Vector3(2, 2, 2);
        private float fov = (float)Math.PI / 4;

        private List<Vector3> vectorBuffer;
        private int vectorLimitSize = 10;


        // default settings
        private string getVectorOperation = "getV";
        private char vectorBigin = '(';
        private char vectorEnd = ')';
        private char vectorParser = ',';

        SerialPort serialPort = null;
        private int serialPortBaudRate = 9600;
        private int serialPortDataBits = 8;

        public MainWindow()
        {
            InitializeComponent();

            glControl = new GLControl() { Dock = DockStyle.Fill };
            splitContainer_main.Panel2.Controls.Add(glControl);

            glControl.Load += glControl_Load;
            glControl.Resize += glControl_Resize;
            glControl.Paint += glControl_Paint;

            vectorBuffer = new List<Vector3>();

            serialPort = new SerialPort();
            serialPort.DataReceived += serialPort_DataReceived;

            textBox_serialPortDataBits.Text = serialPortDataBits.ToString();
            textBox_serialPortBaudRate.Text = serialPortBaudRate.ToString();
            textBox_getVectorOperation.Text = getVectorOperation;
            textBox_beginVector.Text = vectorBigin.ToString();
            textBox_endVector.Text = vectorEnd.ToString();
            textBox_parserVector.Text = vectorParser.ToString();
        }

        private void glControl_Load(object sender, EventArgs e)
        {
            GL.ClearColor(backGround);
            GL.Enable(EnableCap.DepthTest);

            GL.Viewport(0, 0, glControl.Size.Width, glControl.Size.Height);
            Projection();
            Modelview();

            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox_port.Items.Add(port);
            }
            if (comboBox_port.Items.Count > 0)
                comboBox_port.SelectedIndex = 0;
        }

        private void glControl_Resize(object sender, EventArgs e)
        {
            GL.Viewport(0, 0, glControl.Size.Width, glControl.Size.Height);
            Projection();
            Modelview();
        }

        private void glControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            GL.Begin(BeginMode.Lines);
            GL.Color4(Color4.Red);
            GL.Vertex3(0.0, 0.0, 0.0);
            GL.Vertex3(1.0, 0.0, 0.0);

            GL.Color4(Color4.Green);
            GL.Vertex3(0.0, 0.0, 0.0);
            GL.Vertex3(0.0, 1.0, 0.0);

            GL.Color4(Color4.Blue); ;
            GL.Vertex3(0.0, 0.0, 0.0);
            GL.Vertex3(0.0, 0.0, 1.0);

            foreach (var vec in vectorBuffer)
            {
                //ベクトルごとに色を決めたい
                GL.Color4(Color4.Black);

                GL.Vertex3(0.0, 0.0, 0.0);
                GL.Vertex3(vec);
            }

            GL.End();

            glControl.SwapBuffers();
        }

        private void Modelview()
        {
            //透視射影
            GL.MatrixMode(MatrixMode.Projection);
            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView(fov, (float)glControl.Size.Width / (float)glControl.Size.Height, 0.1f, 1000.0f);
            GL.LoadMatrix(ref projection);
        }

        private void Projection()
        {
            GL.MatrixMode(MatrixMode.Modelview);
            Matrix4 modelview = Matrix4.LookAt(eye, Vector3.Zero, Vector3.UnitY);
            GL.LoadMatrix(ref modelview);
        }

        private void radioButton_serialPortConnect_CheckedChanged(object sender, EventArgs e)
        {
            if (serialPort.IsOpen == true) { return; }
            else
            {
                serialPort.PortName = comboBox_port.SelectedItem.ToString();
                serialPort.BaudRate = int.Parse(textBox_serialPortBaudRate.Text);
                serialPort.DataBits = int.Parse(textBox_serialPortDataBits.Text);
                serialPort.Parity = Parity.None;
                serialPort.StopBits = StopBits.One;
                serialPort.Handshake = Handshake.None;
                serialPort.Encoding = Encoding.Unicode;

                try
                {
                    serialPort.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                textBox_serialPortBaudRate.Enabled = false;
                textBox_serialPortDataBits.Enabled = false;
                textBox_getVectorOperation.Enabled = false;
                textBox_beginVector.Enabled = false;
                textBox_endVector.Enabled = false;
                textBox_parserVector.Enabled = false;
                comboBox_port.Enabled = false;
            }
        }

        private void radioButton_serialPortDisconnect_CheckedChanged(object sender, EventArgs e)
        {
            serialPort.Close();

            textBox_serialPortBaudRate.Enabled = true;
            textBox_serialPortDataBits.Enabled = true;
            textBox_getVectorOperation.Enabled = true;
            textBox_beginVector.Enabled = true;
            textBox_endVector.Enabled = true;
            textBox_parserVector.Enabled = true;
            comboBox_port.Enabled = true;
        }

        private void serialPort_sendData(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Write(textBox_getVectorOperation.Text);
            }
        }

        private void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (serialPort.IsOpen == false) { return; }

            byte[] buf = new byte[1024];
            int len = serialPort.Read(buf, 0, 1024);
            string str = Encoding.UTF8.GetString(buf, 0, len);

            try
            {
                if (str == null) { return; }
                Invoke(new Delegate_RcvData(RcvData), str);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            serialPort.DiscardInBuffer();
        }


        delegate void Delegate_RcvData(string str);
        void RcvData(string text)
        {
            textBox_vectorLog.AppendText(text + "\n\n");

            vectorBigin = textBox_beginVector.Text[0];
            vectorEnd = textBox_endVector.Text[0];
            vectorParser = textBox_parserVector.Text[0];

            if (vectorBigin != text[0]) { return; }
            else if (vectorEnd != text.Last()) { return; }

            string s_vec = text.Trim(vectorBigin, vectorEnd);
            string[] xyz = s_vec.Split(vectorParser);

            float x = float.Parse(xyz[0]);
            float y = float.Parse(xyz[1]);
            float z = float.Parse(xyz[2]);

            vectorBuffer.Add(new Vector3(x, y, z));

            if (vectorBuffer.Count() > vectorLimitSize)
            {
                vectorBuffer.RemoveAt(0);
            }

            glControl.Refresh();
        }
    }
}
